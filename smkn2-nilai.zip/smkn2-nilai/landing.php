<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DigiGrade SMKN 2 Magelang</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1565C0;
            --primary-light: #42A5F5;
            --secondary: #7B1FA2;
            --accent: #2635beff;
            --light: #FFFFFF;
            --dark: #263238;
            --blue-bg: #E3F2FD;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: var(--white-bg);
            color: var(--dark);
            overflow-x: hidden;
        }
        
        /* Header */
        header {
            background: var(--light);
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            z-index: 100;
        }
        
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 8%;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .school-logo {
            height: 50px;
            width: auto;
        }
        
        .logo-text {
            display: flex;
            flex-direction: column;
        }
        
        .logo-main {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
            line-height: 1;
        }
        
        .logo-sub {
            font-size: 0.9rem;
            color: var(--secondary);
            font-weight: 500;
        }
        
        .nav-links {
            display: flex;
            
    align-items: center;
            gap: 2rem;
        }
        
        .nav-links a {
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            transition: 0.3s;
            position: relative;
        }
        
        .nav-links a:hover {
            color: var(--primary);
        }
        
        .nav-links a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary);
            bottom: -5px;
            left: 0;
            transition: 0.3s;
        }
        
        .nav-links a:hover:after {
            width: 100%;
        }
        
        .login-btn {
            background: var(--accent);
            color: white;
            padding: 0.6rem 1.5rem;
            border-radius: 50px;
            font-weight: 600;
            transition: 0.3s;
            box-shadow: 0 3px 10px rgba(89, 34, 192, 0.3);
        }
        
        .login-btn:hover {
            transform: translateY(-3px);
          box-shadow: 0 3px 10px rgba(89, 34, 192, 0.3);
        }
        
        /* Hero Section */
        .hero {
            padding: 8rem 8% 5rem;
            display: flex;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(21,101,192,0.1) 0%, rgba(66,165,245,0.2) 100%);
            position: relative;
            overflow: hidden;
        }
        
        .hero:before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(66,165,245,0.15) 0%, rgba(66,165,245,0) 70%);
            top: -100px;
            right: -100px;
            z-index: 0;
        }
        
        .hero:after {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(123,31,162,0.1) 0%, rgba(123,31,162,0) 70%);
            bottom: -150px;
            left: -150px;
            z-index: 0;
        }
        
        .hero-content {
            flex: 1;
            position: relative;
            z-index: 1;
        }
        
        .hero h1 {
            font-size: 3.5rem;
            line-height: 1.2;
            margin-bottom: 1.5rem;
            color: var(--primary);
        }
        
        .hero h1 span {
            color: var(--secondary);
        }
        
        .hero p {
            font-size: 1.2rem;
            color: #455A64;
            margin-bottom: 2rem;
            max-width: 600px;
        }
        
        .cta-buttons {
            display: flex;
            gap: 1.5rem;
        }
        
        .primary-btn {
            background: var(--primary);
            color: white;
            padding: 0.8rem 2rem;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            box-shadow: 0 4px 12px rgba(21,101,192,0.3);
        }
        
        .primary-btn:hover {
            background: var(--primary-light);
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(21,101,192,0.4);
        }
        
        .secondary-btn {
            background: transparent;
            color: var(--primary);
            padding: 0.8rem 2rem;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s;
            border: 2px solid var(--primary);
            cursor: pointer;
            font-size: 1rem;
        }
        
        .secondary-btn:hover {
            background: rgba(66,165,245,0.1);
            transform: translateY(-3px);
        }
        
        .hero-image {
            flex: 1;
            display: flex;
            justify-content: center;
            position: relative;
            z-index: 1;
        }
        
        .hero-image img {
            width: 100%;
            max-width: 600px;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        
        /* Features Section */
        .features {
            padding: 5rem 8%;
            background: var(--light);
            position: relative;
        }
        
        .features:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 20px;
            background: linear-gradient(to right, var(--primary), var(--secondary));
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            color: var(--primary);
            position: relative;
            display: inline-block;
        }
        
        .section-title h2:after {
            content: '';
            position: absolute;
            width: 50%;
            height: 3px;
            background: var(--accent);
            bottom: -10px;
            left: 25%;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }
        
        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: 0.3s;
            border-top: 4px solid var(--primary);
            position: relative;
            overflow: hidden;
        }
        
        .feature-card:after {
            content: '';
            position: absolute;
            width: 100%;
            height: 4px;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            bottom: 0;
            left: 0;
            transform: scaleX(0);
            transform-origin: left;
            transition: 0.3s;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        .feature-card:hover:after {
            transform: scaleX(1);
        }
        
        .feature-icon {
            font-size: 3rem;
            margin-bottom: 1.5rem;
            color: var(--primary);
        }
        
        .feature-card h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: var(--primary);
        }
        
        /* About Section */
        .about {
            padding: 5rem 8%;
            background: var(--blue-bg);
            display: flex;
            align-items: center;
            gap: 3rem;
        }
        
        .about-image {
            flex: 1;
        }
        
        .about-image img {
            width: 100%;
            max-width: 500px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .about-content {
            flex: 1;
        }
        
        .about h2 {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1.5rem;
        }
        
        .about p {
            font-size: 1.1rem;
            color: #455A64;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }
        
        /* Footer */
        footer {
            background: var(--dark);
            color: white;
            padding: 3rem 8%;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .footer-logo {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            margin-bottom: 1rem;
        }
        
        .footer-logo span {
            color: var(--accent);
        }
        
        .footer-links h3 {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--accent);
        }
        
        .footer-links ul {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 0.5rem;
        }
        
        .footer-links a {
            color: #B0BEC5;
            text-decoration: none;
            transition: 0.3s;
        }
        
        .footer-links a:hover {
            color: white;
        }
        
        .social-links {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .social-links a {
            color: white;
            background: rgba(255,255,255,0.1);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }
        
        .social-links a:hover {
            background: var(--accent);
            transform: translateY(-3px);
        }
        
        .copyright {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.1);
            color: #B0BEC5;
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .about {
                flex-direction: column;
            }
            
            .about-image {
                margin-bottom: 2rem;
            }
        }
        
        @media (max-width: 768px) {
            nav {
                padding: 1rem 5%;
            }
            
            .nav-links {
                display: none;
            }
            
            .hero {
                flex-direction: column;
                padding: 7rem 5% 3rem;
                text-align: center;
            }
            
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .cta-buttons {
                justify-content: center;
            }
            
            .hero-image {
                margin-top: 3rem;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <nav>
            <div class="logo-container">
                <img src="assets/img/logo-smk.png" alt="SMKN 2 Magelang Logo" class="school-logo">
                <div class="logo-text">
                    <div class="logo-main">Digi<span>Grade</span></div>
                    <div class="logo-sub">SMKN 2 Magelang</div>
                </div>
            </div>
            <div class="nav-links">
                <a href="#">Beranda</a>
                <a href="#features">Fitur</a>
                <a href="#about">Tentang</a>
                <a href="http://localhost/smkn2-nilai/index.php?page=login" class="login-btn">Login</a>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Pantau Nilai Digital dengan <span>DigiGrade</span></h1>
            <p>Platform resmi SMKN 2 Magelang untuk akses nilai real-time, lebih cepat dan transparan!</p>
            <div class="cta-buttons">
                <a href="" class="primary-btn">Lihat Nilai Sekarang</a>
                <a href="#" class="secondary-btn">Demo Fitur</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="https://illustrations.popsy.co/amber/digital-nomad.svg" alt="Dashboard DigiGrade">
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="section-title">
            <h2>Fitur Unggulan</h2>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>Nilai Real-Time</h3>
                <p>Update otomatis segera setelah guru melakukan input nilai ke sistem.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h3>Akses Multi-Device</h3>
                <p>Buka platform melalui smartphone, tablet, atau laptop kapan saja.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🔒</div>
                <h3>Keamanan Data</h3>
                <p>Sistem dilindungi enkripsi untuk menjamin kerahasiaan data nilai.</p>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="about-image">
            <img src="assets/img/smk.jpeg">
        </div>
        <div class="about-content">
            <h2>Tentang DigiGrade</h2>
            <p>DigiGrade adalah platform digital inovatif yang dikembangkan oleh SMKN 2 Magelang untuk memodernisasi sistem penilaian akademik. Dengan teknologi terkini, kami memberikan solusi lengkap untuk manajemen nilai siswa.</p>
            <p>Platform ini dirancang khusus untuk memenuhi kebutuhan SMKN 2 Magelang dengan antarmuka yang user-friendly dan fitur-fitur canggih yang memudahkan baik siswa maupun guru dalam memantau perkembangan akademik.</p>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-grid">
            <div class="footer-col">
                <div class="footer-logo">Digi<span>Grade</span></div>
                <p>Platform nilai digital SMKN 2 Magelang yang modern dan terintegrasi.</p>
                <div class="social-links">
                    <a href="#">📱</a>
                    <a href="#">📘</a>
                    <a href="#">📸</a>
                    <a href="#">📧</a>
                </div>
            </div>
            <div class="footer-links">
                <h3>Navigasi</h3>
                <ul>
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#features">Fitur</a></li>
                    <li><a href="#about">Tentang</a></li>
                    <li><a href="#">Login</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h3>Kontak</h3>
                <ul>
                    <li>SMKN 2 Magelang</li>
                    <li>Jl. Contoh No. 123</li>
                    <li>Magelang, Jawa Tengah</li>
                    <li>(0293) 1234567</li>
                </ul>
            </div>
        </div>
        <div class="copyright">
            &copy; 2024 DigiGrade SMKN 2 Magelang. All rights reserved.
        </div>
    </footer>

    <script>
        // Animasi scroll
        document.addEventListener('DOMContentLoaded', function() {
            const featureCards = document.querySelectorAll('.feature-card');
            
            featureCards.forEach((card, index) => {
                card.style.transitionDelay = `${index * 0.1}s`;
            });
            
            // Efek hover untuk tombol
            const buttons = document.querySelectorAll('.primary-btn, .secondary-btn, .login-btn, .social-links a');
            buttons.forEach(button => {
                button.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-3px)';
                });
                button.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });
            
            // Smooth scrolling
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    
                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
        });
    </script>
</body>
</html>