<?php
// Pastikan session sudah dimulai di file utama (index.php) atau di sini
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Koneksi database
$db = new mysqli('127.0.0.1', 'root', '', 'smkn2_nilai');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Cek role pengguna
$is_guru = ($_SESSION['user_type'] === 'guru');

// Tambah galeri - Hanya untuk guru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_guru) {
    if (isset($_POST['add_gallery'])) {
        $judul = $db->real_escape_string($_POST['judul']);
        $deskripsi = $db->real_escape_string($_POST['deskripsi']);
        $gambar = 'default-gallery.jpg';

        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "assets/img/";
            $imageFileType = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["gambar"]["tmp_name"]);

            if ($check !== false) {
                $gambar = uniqid() . '.' . $imageFileType;
                move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_dir . $gambar);
            }
        }

        $db->query("INSERT INTO galeri (judul, deskripsi, gambar, created_at) VALUES ('$judul', '$deskripsi', '$gambar', NOW())");
       echo "<script>window.location.href='index.php?page=galeri';</script>";
    exit();
    }

    // Edit galeri - Hanya untuk guru
    if (isset($_POST['edit_gallery'])) {
        $id = (int)$_POST['id'];
        $judul = $db->real_escape_string($_POST['judul']);
        $deskripsi = $db->real_escape_string($_POST['deskripsi']);

        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "assets/img/";
            $imageFileType = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["gambar"]["tmp_name"]);

            if ($check !== false) {
                $gambar = uniqid() . '.' . $imageFileType;
                move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_dir . $gambar);

                $old = $db->query("SELECT gambar FROM galeri WHERE id=$id")->fetch_assoc();
                if ($old['gambar'] != 'default-gallery.jpg' && file_exists($target_dir . $old['gambar'])) {
                    unlink($target_dir . $old['gambar']);
                }

                $db->query("UPDATE galeri SET judul='$judul', deskripsi='$deskripsi', gambar='$gambar' WHERE id=$id");
            }
        } else {
            $db->query("UPDATE galeri SET judul='$judul', deskripsi='$deskripsi' WHERE id=$id");
        }

        echo "<script>window.location.href='index.php?page=galeri';</script>";
    exit();
    }
}

// Hapus galeri - Hanya untuk guru
if (isset($_GET['delete']) && $is_guru) {
    $id = (int)$_GET['delete'];
    $result = $db->query("SELECT gambar FROM galeri WHERE id = $id");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['gambar'] != 'default-gallery.jpg' && file_exists("assets/img/" . $row['gambar'])) {
            unlink("assets/img/" . $row['gambar']);
        }
    }
    $db->query("DELETE FROM galeri WHERE id=$id");
    echo "<script>window.location.href='index.php?page=galeri';</script>";
    exit();
}

// Ambil semua data galeri
$galeri = $db->query("SELECT * FROM galeri ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Galeri SMKN 2 Magelang</title>
    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Galeri SMKN 2 Magelang</h3>
        <?php if ($is_guru): ?>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addGalleryModal">
                <i class="fas fa-plus"></i> Tambah Galeri
            </button>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['edit']) && $is_guru): 
        $edit_id = (int)$_GET['edit'];
        $edit_item = $db->query("SELECT * FROM galeri WHERE id = $edit_id")->fetch_assoc(); ?>
        <div class="modal fade show" id="editGalleryModal" style="display:block;" tabindex="-1" aria-modal="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Galeri</h5>
                            <a href="index.php?page=galeri" class="btn-close"></a>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?= $edit_item['id'] ?>">
                            <div class="mb-3">
                                <label class="form-label">Judul</label>
                                <input type="text" name="judul" value="<?= htmlspecialchars($edit_item['judul']) ?>" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control"><?= htmlspecialchars($edit_item['deskripsi']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Gambar (opsional)</label>
                                <input type="file" name="gambar" class="form-control">
                                <img src="assets/img/<?= $edit_item['gambar'] ?>" class="mt-2 rounded" style="width:100%; max-height:150px; object-fit:cover;">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="index.php?page=galeri" class="btn btn-secondary">Batal</a>
                            <button name="edit_gallery" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show"></div>
    <?php endif; ?>

    <div class="row">
        <?php if ($galeri->num_rows > 0): ?>
            <?php while ($item = $galeri->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="assets/img/<?= $item['gambar'] ?>" class="card-img-top" alt="<?= htmlspecialchars($item['judul']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($item['judul']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($item['deskripsi']) ?></p>
                        </div>
                        <?php if ($is_guru): ?>
                            <div class="card-footer d-flex justify-content-between">
                                <a href="?page=galeri&edit=<?= $item['id'] ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                <a href="?page=galeri&delete=<?= $item['id'] ?>" onclick="return confirm('Hapus item ini?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="alert alert-info">Belum ada galeri. <?= $is_guru ? 'Tambahkan sekarang!' : '' ?></div>
        <?php endif; ?>
    </div>
</div>

<?php if ($is_guru): ?>
<!-- Modal Tambah - Hanya ditampilkan untuk guru -->
<div class="modal fade" id="addGalleryModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Galeri Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Judul</label>
                    <input type="text" name="judul" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Gambar</label>
                    <input type="file" name="gambar" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button name="add_gallery" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="card shadow">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tentang SMKN 2 Magelang</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-8">
                <h5>Visi Sekolah</h5>
                <p>Menjadi sekolah menengah kejuruan yang unggul dalam menghasilkan tenaga kerja yang profesional, berkarakter, dan berdaya saing global.</p>
                
                <h5>Misi Sekolah</h5>
                <ul>
                    <li>Menyelenggarakan pendidikan kejuruan yang berkualitas dan relevan dengan kebutuhan industri</li>
                    <li>Mengembangkan kompetensi siswa yang sesuai dengan standar industri</li>
                    <li>Membentuk karakter siswa yang berakhlak mulia dan berjiwa entrepreneur</li>
                    <li>Menghasilkan lulusan yang siap kerja dan mampu bersaing di era global</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <h5>Program Keahlian</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-code text-succes"></i> PPLG</li>
                    <li><i class="fas fa-network-wired text-danger"></i> PM</li>
                    <li><i class="fas fa-microchip text-info"></i> MPLB</li>
                    <li><i class="fas fa-car text-warning"></i> AKL</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>