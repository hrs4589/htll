<?php
// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $nis = $_POST['nis'];
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $jk = $_POST['jk'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO siswa (nis, nama, kelas, jk, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nis, $nama, $kelas, $jk, $password]);
        $message = "Siswa berhasil ditambahkan!";
        $messageType = "success";
    } elseif ($action === 'update') {
        $id = $_POST['id'];
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $jk = $_POST['jk'];
        
        $stmt = $pdo->prepare("UPDATE siswa SET nama = ?, kelas = ?, jk = ? WHERE nis = ?");
        $stmt->execute([$nama, $kelas, $jk, $id]);
        $message = "Data siswa berhasil diupdate!";
        $messageType = "success";
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM siswa WHERE nis = ?");
        $stmt->execute([$id]);
        $message = "Siswa berhasil dihapus!";
        $messageType = "success";
    }
}

// Get all students
$stmt = $pdo->query("SELECT * FROM siswa ORDER BY kelas, nama");
$students = $stmt->fetchAll();

// Get statistics
$total_students = count($students);
$male_count = count(array_filter($students, function($s) { return $s['jk'] === 'L'; }));
$female_count = count(array_filter($students, function($s) { return $s['jk'] === 'P'; }));
$classes = array_unique(array_column($students, 'kelas'));
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
    <h1 class="h2 text-gradient">
        <i class="bi bi-people"></i> Data Siswa
    </h1>
    <div class="btn-toolbar">
        <button class="btn btn-primary me-2" onclick="openAddModal('siswa')">
            <i class="bi bi-person-plus"></i> Tambah Siswa
        </button>
        <div class="btn-group">
            <button class="btn btn-outline-primary" onclick="exportData('csv', 'siswaTable')">
                <i class="bi bi-download"></i> Export
            </button>
            <button class="btn btn-outline-primary" onclick="printTable('siswaTable')">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
    </div>
</div>

<?php if (isset($message)): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <i class="bi bi-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card primary">
            <div class="stats-icon">
                <i class="bi bi-people"></i>
            </div>
            <div class="stats-number"><?= $total_students ?></div>
            <div class="stats-label">Total Siswa</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card info">
            <div class="stats-icon">
                <i class="bi bi-gender-male"></i>
            </div>
            <div class="stats-number"><?= $male_count ?></div>
            <div class="stats-label">Laki-laki</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card warning">
            <div class="stats-icon">
                <i class="bi bi-gender-female"></i>
            </div>
            <div class="stats-number"><?= $female_count ?></div>
            <div class="stats-label">Perempuan</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card success">
            <div class="stats-icon">
                <i class="bi bi-building"></i>
            </div>
            <div class="stats-number"><?= count($classes) ?></div>
            <div class="stats-label">Total Kelas</div>
        </div>
    </div>
</div>

<!-- Students Table -->
<div class="card shadow-custom border-radius-custom">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-table"></i> Daftar Siswa SMKN 2 Magelang
        </h5>
        <div class="input-group" style="width: 300px;">
            <span class="input-group-text">
                <i class="bi bi-search"></i>
            </span>
            <input type="text" class="form-control" placeholder="Cari siswa..." 
                   onkeyup="searchTable(this.value, 'siswaTable')">
        </div>
    </div>
    <div class="card-body p-0">
        <?php if (empty($students)): ?>
            <div class="text-center py-5">
                <i class="bi bi-person-x display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">Belum Ada Data Siswa</h4>
                <p class="text-muted">Tambahkan siswa pertama untuk memulai.</p>
                <button class="btn btn-primary" onclick="openAddModal('siswa')">
                    <i class="bi bi-person-plus"></i> Tambah Siswa Pertama
                </button>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table class="table table-hover mb-0" id="siswaTable">
                    <thead>
                        <tr>
                            <th><i class="bi bi-hash me-1"></i> NIS</th>
                            <th><i class="bi bi-person me-1"></i> Nama Lengkap</th>
                            <th><i class="bi bi-building me-1"></i> Kelas</th>
                            <th><i class="bi bi-gender-ambiguous me-1"></i> Jenis Kelamin</th>
                            <th><i class="bi bi-image me-1"></i> Foto</th>
                            <th class="text-center"><i class="bi bi-gear me-1"></i> Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-primary fs-6"><?= $student['nis'] ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary rounded-circle p-2 me-3">
                                            <i class="bi bi-person text-white"></i>
                                        </div>
                                        <strong><?= $student['nama'] ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info fs-6"><?= $student['kelas'] ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-<?= $student['jk'] === 'L' ? 'gender-male text-primary' : 'gender-female text-danger' ?> me-2"></i>
                                        <?= $student['jk'] === 'L' ? 'Laki-laki' : 'Perempuan' ?>
                                    </div>
                                </td>
                                <td>
                                    <img src="assets/img/<?= $student['foto'] ?>" 
                                         alt="<?= $student['nama'] ?>" 
                                         class="rounded-circle shadow-sm" 
                                         width="40" height="40">
                                </td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="openEditModal('siswa', '<?= $student['nis'] ?>', <?= htmlspecialchars(json_encode($student)) ?>)"
                                                data-bs-toggle="tooltip" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="deleteItem('siswa', '<?= $student['nis'] ?>', '<?= $student['nama'] ?>')"
                                                data-bs-toggle="tooltip" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal for Add/Edit Siswa -->
<div class="modal fade" id="siswaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-person-plus"></i> Tambah Siswa
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="siswaForm" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-hash"></i> NIS
                        </label>
                        <input type="text" class="form-control" name="nis" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-person"></i> Nama Lengkap
                        </label>
                        <input type="text" class="form-control" name="nama" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-building"></i> Kelas
                        </label>
                        <select class="form-select" name="kelas" required>
                            <option value="">-- Pilih Kelas --</option>
                            <option value="XII PPLG 1">XII PPLG 1</option>
                            <option value="XII PPLG 2">XII PPLG 2</option>
                         
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-gender-ambiguous"></i> Jenis Kelamin
                        </label>
                        <select class="form-select" name="jk" required>
                            <option value="">-- Pilih Jenis Kelamin --</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="passwordField">
                        <label class="form-label">
                            <i class="bi bi-lock"></i> Password
                        </label>
                        <input type="password" class="form-control" name="password" required>
                        <div class="form-text">Password default untuk login siswa</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Confirm Delete Modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="bi bi-exclamation-triangle"></i> Konfirmasi Hapus
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <i class="bi bi-person-x display-1 text-danger mb-3"></i>
                <h4>Yakin ingin menghapus siswa?</h4>
                <p class="text-muted">Siswa <strong id="deleteItemName"></strong> dan semua data nilainya akan dihapus permanen.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Batal
                </button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="deleteItemId">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Override the modal functions for this page
function openAddModal(type) {
    const modal = new bootstrap.Modal(document.getElementById('siswaModal'));
    const form = document.getElementById('siswaForm');
    
    // Reset form
    form.reset();
    form.action = '';
    
    // Show password field for new student
    document.getElementById('passwordField').style.display = 'block';
    document.querySelector('[name="password"]').required = true;
    
    // Update modal title
    document.querySelector('#siswaModal .modal-title').innerHTML = '<i class="bi bi-person-plus"></i> Tambah Siswa';
    
    // Add hidden input for action
    let actionInput = form.querySelector('[name="action"]');
    if (!actionInput) {
        actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        form.appendChild(actionInput);
    }
    actionInput.value = 'create';
    
    modal.show();
}

function openEditModal(type, id, data) {
    const modal = new bootstrap.Modal(document.getElementById('siswaModal'));
    const form = document.getElementById('siswaForm');
    
    // Populate form with data
    form.querySelector('[name="nis"]').value = data.nis;
    form.querySelector('[name="nis"]').readOnly = true;
    form.querySelector('[name="nama"]').value = data.nama;
    form.querySelector('[name="kelas"]').value = data.kelas;
    form.querySelector('[name="jk"]').value = data.jk;
    
    // Hide password field for edit
    document.getElementById('passwordField').style.display = 'none';
    document.querySelector('[name="password"]').required = false;
    
    // Update modal title
    document.querySelector('#siswaModal .modal-title').innerHTML = '<i class="bi bi-pencil-square"></i> Edit Siswa';
    
    // Add hidden inputs for action and id
    let actionInput = form.querySelector('[name="action"]');
    if (!actionInput) {
        actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        form.appendChild(actionInput);
    }
    actionInput.value = 'update';
    
    let idInput = form.querySelector('[name="id"]');
    if (!idInput) {
        idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        form.appendChild(idInput);
    }
    idInput.value = id;
    
    modal.show();
}

function deleteItem(type, id, name) {
    document.getElementById('deleteItemName').textContent = name;
    document.getElementById('deleteItemId').value = id;
    
    const modal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
    modal.show();
}
</script>