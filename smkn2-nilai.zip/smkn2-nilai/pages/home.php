<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
</div>

<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Siswa
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM siswa");
                            echo $stmt->fetchColumn();
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Guru
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM guru");
                            echo $stmt->fetchColumn();
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chalkboard-teacher fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total Nilai
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM nilai");
                            echo $stmt->fetchColumn();
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Rata-rata Nilai
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $stmt = $pdo->query("SELECT AVG(na) FROM nilai WHERE na > 0");
                            $avg = $stmt->fetchColumn();
                            echo number_format($avg, 2);
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-star fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Selamat Datang</h6>
            </div>
            <div class="card-body">
                <h5>Halo, <?= $_SESSION['user_name'] ?>!</h5>
                <p>Selamat datang di Sistem Nilai Siswa SMKN 2 Magelang.</p>
                
                <?php if (isGuru()): ?>
                    <p>Sebagai guru, Anda dapat:</p>
                    <ul>
                        <li>Menginput nilai siswa untuk berbagai mata pelajaran</li>
                        <li>Melihat data siswa dan guru</li>
                        <li>Mengelola nilai UTS, UAS, dan Tugas</li>
                    </ul>
                    <a href="index.php?page=nilai_siswa" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Input Nilai
                    </a>
                <?php else: ?>
                    <p>Sebagai siswa, Anda dapat:</p>
                    <ul>
                        <li>Melihat nilai Anda untuk semua mata pelajaran</li>
                        <li>Melihat grade dan nilai akhir</li>
                        <li>Memantau progress akademik</li>
                    </ul>
                    <a href="index.php?page=nilai_siswa" class="btn btn-primary">
                        <i class="fas fa-eye"></i> Lihat Nilai
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Sistem</h6>
            </div>
            <div class="card-body">
                <h6>Mata Pelajaran yang Tersedia:</h6>
                <ul>
                    <li>Bahasa Indonesia</li>
                    <li>Bahasa Inggris</li>
                    <li>Matematika</li>
                </ul>
                
                <h6>Sistem Penilaian:</h6>
                <p>Nilai Akhir = (UTS + UAS + Tugas) / 3</p>
                
                <h6>Grade:</h6>
                <ul class="list-unstyled">
                    <li><span class="badge bg-success">A</span> 90 - 100</li>
                    <li><span class="badge bg-primary">B</span> 80 - 89</li>
                    <li><span class="badge bg-warning">C</span> 70 - 79</li>
                    <li><span class="badge bg-info">D</span> 50 - 69</li>
                    <li><span class="badge bg-danger">E</span> 0 - 49</li>
                </ul>
            </div>
        </div>
    </div>
</div>