<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username && $password) {
        // Check if user is a teacher (guru)
        $stmt = $pdo->prepare("SELECT nip as id, nama, password, 'guru' as type FROM guru WHERE nip = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        // If not found in guru table, check siswa table
        if (!$user) {
            $stmt = $pdo->prepare("SELECT nis as id, nama, password, 'siswa' as type FROM siswa WHERE nis = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
        }
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nama'];
            $_SESSION['user_type'] = $user['type'];
            
            header('Location: index.php');
            exit();
        } else {
            $error = "Username atau password salah!";
        }
    }
}
?>

<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <img src="assets/img/logo-smk.png" alt="SMKN 2 Magelang" class="logo">
            <h2>DigiGrade</h2>
            <h3>SMKN 2 Magelang</h3>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST" class="login-form">
            <div class="form-group">
                <label for="username">Username (NIS/NIP/Email)</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn btn-primary btn-login">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
        
        <div class="login-info">
            <small class="text-muted">
                <strong>Demo Accounts:</strong><br>
                Guru: NIP: 123456789, Password: password123<br>
                Siswa: NIS: 17342, Password: password123
            </small>
        </div>
    </div>
</div>