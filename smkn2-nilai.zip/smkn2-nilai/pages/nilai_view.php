<?php
// Get current student's grades
$nis = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT n.*, s.nama, s.kelas 
    FROM nilai n 
    INNER JOIN siswa s ON n.nis = s.nis 
    WHERE n.nis = ? 
    ORDER BY n.mapel
");
$stmt->execute([$nis]);
$grades = $stmt->fetchAll();

// Calculate statistics
$total_na = 0;
$count = 0;
foreach ($grades as $grade) {
    if ($grade['na'] > 0) {
        $total_na += $grade['na'];
        $count++;
    }
}
$average = $count > 0 ? $total_na / $count : 0;
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Nilai Saya</h1>
</div>

<div class="row mb-4">
    <div class="col-lg-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <div class="text-white-50 small">Rata-rata Nilai</div>
                <div class="h4 mb-0"><?= number_format($average, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                <div class="text-white-50 small">Total Mata Pelajaran</div>
                <div class="h4 mb-0"><?= count($grades) ?></div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card bg-info text-white shadow">
            <div class="card-body">
                <div class="text-white-50 small">Grade Rata-rata</div>
                <div class="h4 mb-0"><?= calculateGrade($average) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Detail Nilai</h6>
    </div>
    <div class="card-body">
        <?php if (empty($grades)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Belum ada nilai yang tersedia.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-primary">
                        <tr>
                            <th>Mata Pelajaran</th>
                            <th>UTS</th>
                            <th>UAS</th>
                            <th>Tugas</th>
                            <th>Nilai Akhir (NA)</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades as $grade): ?>
                            <tr>
                                <td><strong><?= $grade['mapel'] ?></strong></td>
                                <td><?= $grade['uts'] ?></td>
                                <td><?= $grade['uas'] ?></td>
                                <td><?= $grade['tugas'] ?></td>
                                <td><strong><?= $grade['na'] ?></strong></td>
                                <td>
                                    <span class="badge bg-<?= getGradeBadgeColor($grade['grade']) ?> fs-6">
                                        <?= $grade['grade'] ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card shadow">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Informasi Penilaian</h6>
    </div>
    <div class="card-body">
        <h6>Rumus Perhitungan:</h6>
        <p>Nilai Akhir (NA) = (UTS + UAS + Tugas) / 3</p>
        
        <h6>Keterangan Grade:</h6>
        <div class="row">
            <div class="col-md-6">
                <ul class="list-unstyled">
                    <li><span class="badge bg-success">A</span> Excellent (90 - 100)</li>
                    <li><span class="badge bg-primary">B</span> Good (80 - 89)</li>
                    <li><span class="badge bg-warning">C</span> Fair (70 - 79)</li>
                </ul>
            </div>
            <div class="col-md-6">
                <ul class="list-unstyled">
                    <li><span class="badge bg-info">D</span> Poor (50 - 69)</li>
                    <li><span class="badge bg-danger">E</span> Fail (0 - 49)</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
function calculateGrade($na) {
    if ($na >= 90) return 'A';
    elseif ($na >= 80) return 'B';
    elseif ($na >= 70) return 'C';
    elseif ($na >= 50) return 'D';
    else return 'E';
}

function getGradeBadgeColor($grade) {
    switch($grade) {
        case 'A': return 'success';
        case 'B': return 'primary';
        case 'C': return 'warning';
        case 'D': return 'info';
        case 'E': return 'danger';
        default: return 'secondary';
    }
}
?>