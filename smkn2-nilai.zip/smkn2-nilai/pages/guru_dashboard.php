<?php
// Get statistics for guru dashboard
$stmt = $pdo->query("SELECT COUNT(*) FROM siswa");
$total_siswa = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM nilai");
$total_nilai = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT AVG(na) FROM nilai WHERE na > 0");
$rata_nilai = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM guru");
$total_guru = $stmt->fetchColumn();

// Get recent grades
$stmt = $pdo->query("
    SELECT n.*, s.nama, s.kelas 
    FROM nilai n 
    INNER JOIN siswa s ON n.nis = s.nis 
    ORDER BY n.updated_at DESC 
    LIMIT 10
");
$recent_grades = $stmt->fetchAll();

// Get grade distribution
$stmt = $pdo->query("
    SELECT grade, COUNT(*) as count 
    FROM nilai 
    WHERE na > 0 
    GROUP BY grade 
    ORDER BY grade
");
$grade_distribution = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
    <h1 class="h2 text-gradient">
        <i class="bi bi-speedometer2"></i> Dashboard Guru
    </h1>
    <div class="btn-toolbar">
        <button class="btn btn-primary me-2" onclick="openAddModal('nilai')">
            <i class="bi bi-plus-circle"></i> Input Nilai
        </button>
        <button class="btn btn-outline-primary" onclick="exportData('csv', 'nilaiTable')">
            <i class="bi bi-download"></i> Export
        </button>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card primary">
            <div class="stats-icon">
                <i class="bi bi-people"></i>
            </div>
            <div class="stats-number"><?= $total_siswa ?></div>
            <div class="stats-label">Total Siswa</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card success">
            <div class="stats-icon">
                <i class="bi bi-clipboard-data"></i>
            </div>
            <div class="stats-number"><?= $total_nilai ?></div>
            <div class="stats-label">Total Nilai</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card warning">
            <div class="stats-icon">
                <i class="bi bi-graph-up"></i>
            </div>
            <div class="stats-number"><?= number_format($rata_nilai, 1) ?></div>
            <div class="stats-label">Rata-rata Nilai</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card info">
            <div class="stats-icon">
                <i class="bi bi-person-check"></i>
            </div>
            <div class="stats-number"><?= $total_guru ?></div>
            <div class="stats-label">Total Guru</div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="row">
    <!-- Quick Actions -->
    <div class="col-lg-4">
        <div class="card shadow-custom border-radius-custom mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="bi bi-lightning"></i> Aksi Cepat
                </h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-3">
                    <button class="btn btn-primary btn-lg" onclick="openAddModal('nilai')">
                        <i class="bi bi-plus-circle me-2"></i>
                        Input Nilai Baru
                    </button>
                    <button class="btn btn-success btn-lg" onclick="openAddModal('siswa')">
                        <i class="bi bi-person-plus me-2"></i>
                        Tambah Siswa
                    </button>
                    <button class="btn btn-info btn-lg" onclick="window.location.href='index.php?page=data_siswa'">
                        <i class="bi bi-people me-2"></i>
                        Kelola Data Siswa
                    </button>
                    <button class="btn btn-warning btn-lg" onclick="printTable('nilaiTable')">
                        <i class="bi bi-printer me-2"></i>
                        Cetak Laporan
                    </button>
                </div>
            </div>
        </div>

        <!-- Grade Distribution -->
        <div class="card shadow-custom border-radius-custom">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-pie-chart"></i> Distribusi Grade
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($grade_distribution)): ?>
                    <p class="text-muted text-center">Belum ada data grade</p>
                <?php else: ?>
                    <?php foreach ($grade_distribution as $grade): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-<?= getGradeBadgeColor($grade['grade']) ?> me-2"><?= $grade['grade'] ?></span>
                                <span>Grade <?= $grade['grade'] ?></span>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="fw-bold me-2"><?= $grade['count'] ?></span>
                                <div class="progress" style="width: 60px; height: 8px;">
                                    <div class="progress-bar bg-<?= getGradeBadgeColor($grade['grade']) ?>" 
                                         style="width: <?= $total_nilai > 0 ? ($grade['count'] / $total_nilai) * 100 : 0 ?>%"></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Grades -->
    <div class="col-lg-8">
        <div class="card shadow-custom border-radius-custom">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-clock-history"></i> Nilai Terbaru
                </h5>
                <div class="input-group" style="width: 250px;">
                    <span class="input-group-text">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="text" class="form-control" placeholder="Cari siswa..." 
                           onkeyup="searchTable(this.value, 'nilaiTable')">
                </div>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recent_grades)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <h4 class="mt-3 text-muted">Belum Ada Nilai</h4>
                        <p class="text-muted">Mulai input nilai siswa untuk melihat data di sini.</p>
                        <button class="btn btn-primary" onclick="openAddModal('nilai')">
                            <i class="bi bi-plus-circle"></i> Input Nilai Pertama
                        </button>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table table-hover mb-0" id="nilaiTable">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-person me-1"></i> Siswa</th>
                                    <th><i class="bi bi-building me-1"></i> Kelas</th>
                                    <th><i class="bi bi-book me-1"></i> Mata Pelajaran</th>
                                    <th class="text-center"><i class="bi bi-1-circle me-1"></i> UTS</th>
                                    <th class="text-center"><i class="bi bi-2-circle me-1"></i> UAS</th>
                                    <th class="text-center"><i class="bi bi-3-circle me-1"></i> Tugas</th>
                                   
                                
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_grades as $grade): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary rounded-circle p-2 me-2">
                                                    <i class="bi bi-person text-white"></i>
                                                </div>
                                                <strong><?= $grade['nama'] ?></strong>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?= $grade['kelas'] ?></span>
                                        </td>
                                        <td><?= $grade['mapel'] ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark"><?= $grade['uts'] ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark"><?= $grade['uas'] ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark"><?= $grade['tugas'] ?></span>
                                        </td>
                                       
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Input Nilai -->
<div class="modal fade" id="nilaiModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle"></i> Input Nilai
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="nilaiForm" onsubmit="event.preventDefault(); submitForm('nilai');">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-person"></i> Pilih Siswa
                                </label>
                                <select class="form-select" name="nis" required>
                                    <option value="">-- Pilih Siswa --</option>
                                    <?php
                                    $stmt = $pdo->query("SELECT nis, nama, kelas FROM siswa ORDER BY kelas, nama");
                                    $students = $stmt->fetchAll();
                                    foreach ($students as $student):
                                    ?>
                                        <option value="<?= $student['nis'] ?>">
                                            <?= $student['nama'] ?> (<?= $student['kelas'] ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-book"></i> Mata Pelajaran
                                </label>
                                <select class="form-select" name="mapel" required>
                                    <option value="">-- Pilih Mata Pelajaran --</option>
                                    <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                                    <option value="Bahasa Inggris">Bahasa Inggris</option>
                                    <option value="Matematika">Matematika</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-1-circle"></i> Nilai UTS
                                </label>
                                <input type="number" class="form-control" id="uts" name="uts" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-2-circle"></i> Nilai UAS
                                </label>
                                <input type="number" class="form-control" id="uas" name="uas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-3-circle"></i> Nilai Tugas
                                </label>
                                <input type="number" class="form-control" id="tugas" name="tugas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-calculator"></i> Nilai Akhir (NA)
                                </label>
                                <input type="number" class="form-control" id="na" name="na" 
                                       step="0.01" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-award"></i> Grade
                                </label>
                                <input type="text" class="form-control" id="grade" name="grade" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Confirm Delete Modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="bi bi-exclamation-triangle"></i> Konfirmasi Hapus
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <i class="bi bi-trash display-1 text-danger mb-3"></i>
                <h4>Yakin ingin menghapus?</h4>
                <p class="text-muted">Data <strong id="deleteItemName"></strong> akan dihapus permanen.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Batal
                </button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
                    <i class="bi bi-trash"></i> Hapus
                </button>
            </div>
        </div>
    </div>
</div>

<?php
function getGradeBadgeColor($grade) {
    switch($grade) {
        case 'A': return 'success';
        case 'B': return 'primary';
        case 'C': return 'warning';
        case 'D': return 'info';
        case 'E': return 'danger';
        default: return 'secondary';
    }
}
?>