<?php
// Get current student's data
$nis = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM siswa WHERE nis = ?");
$stmt->execute([$nis]);
$student = $stmt->fetch();

// Get student's grades
$stmt = $pdo->prepare("SELECT * FROM nilai WHERE nis = ? ORDER BY mapel");
$stmt->execute([$nis]);
$grades = $stmt->fetchAll();

// Calculate statistics
$total_na = 0;
$count = 0;
$grade_counts = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'E' => 0];

foreach ($grades as $grade) {
    if ($grade['na'] > 0) {
        $total_na += $grade['na'];
        $count++;
        $grade_counts[$grade['grade']]++;
    }
}
$average = $count > 0 ? $total_na / $count : 0;
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
    <h1 class="h2 text-gradient">
        <i class="bi bi-person-circle"></i> Dashboard Siswa
    </h1>
    <div class="text-muted">
        <i class="bi bi-calendar3"></i> <?= date('d F Y') ?>
    </div>
</div>

<!-- Student Profile Card -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card shadow-custom border-radius-custom">
            <div class="card-body p-4">
                <div class="row align-items-center">
                    <div class="col-md-3 text-center">
                        <div class="position-relative d-inline-block">
                            <img src="assets/img/<?= $student['foto'] ?>" alt="<?= $student['nama'] ?>" 
                                 class="rounded-circle shadow-lg" width="120" height="120"
                                 style="border: 4px solid var(--primary-color);">
                            <div class="position-absolute bottom-0 end-0">
                                <span class="badge bg-success rounded-pill p-2">
                                    <i class="bi bi-check-circle"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h3 class="mb-2 text-primary"><?= $student['nama'] ?></h3>
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-person-badge text-primary me-2"></i>
                                    <div>
                                        <small class="text-muted d-block">NIS</small>
                                        <strong><?= $student['nis'] ?></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-building text-primary me-2"></i>
                                    <div>
                                        <small class="text-muted d-block">Kelas</small>
                                        <strong><?= $student['kelas'] ?></strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="stats-card bg-gradient-primary text-white p-3 rounded">
                                <div class="stats-number text-white"><?= number_format($average, 1) ?></div>
                                <div class="stats-label text-white-50">Rata-rata Nilai</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card primary">
            <div class="stats-icon">
                <i class="bi bi-book"></i>
            </div>
            <div class="stats-number"><?= count($grades) ?></div>
            <div class="stats-label">Mata Pelajaran</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card success">
            <div class="stats-icon">
                <i class="bi bi-trophy"></i>
            </div>
            <div class="stats-number"><?= $grade_counts['A'] ?></div>
            <div class="stats-label">Grade A</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card warning">
            <div class="stats-icon">
                <i class="bi bi-star"></i>
            </div>
            <div class="stats-number"><?= $grade_counts['B'] ?></div>
            <div class="stats-label">Grade B</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card info">
            <div class="stats-icon">
                <i class="bi bi-graph-up"></i>
            </div>
            <div class="stats-number"><?= number_format(($grade_counts['A'] + $grade_counts['B']) / max(count($grades), 1) * 100, 0) ?>%</div>
            <div class="stats-label">Tingkat Kelulusan</div>
        </div>
    </div>
</div>

<!-- Grades Overview -->
<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-custom border-radius-custom">
            <div class="card-header bg-gradient-primary text-white">
                <h5 class="mb-0">
                    <i class="bi bi-clipboard-data"></i> Ringkasan Nilai
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($grades)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <h4 class="mt-3 text-muted">Belum Ada Nilai</h4>
                        <p class="text-muted">Nilai Anda akan muncul di sini setelah guru menginput.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-book me-1"></i> Mata Pelajaran</th>
                                    <th class="text-center"><i class="bi bi-1-circle me-1"></i> UTS</th>
                                    <th class="text-center"><i class="bi bi-2-circle me-1"></i> UAS</th>
                                    <th class="text-center"><i class="bi bi-3-circle me-1"></i> Tugas</th>
                                    <th class="text-center"><i class="bi bi-calculator me-1"></i> Nilai Akhir</th>
                                    <th class="text-center"><i class="bi bi-award me-1"></i> Grade</th>
                                      </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($grades as $grade): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary rounded-circle p-2 me-3">
                                                    <i class="bi bi-book text-white"></i>
                                                </div>
                                                <strong><?= $grade['mapel'] ?></strong>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark fs-6"><?= $grade['uts'] ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark fs-6"><?= $grade['uas'] ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark fs-6"><?= $grade['tugas'] ?></span>
                                        </td>
                                        <td class="text-center">
                                            <strong class="fs-5 text-primary"><?= $grade['na'] ?></strong>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?= getGradeBadgeColor($grade['grade']) ?> fs-6 px-3 py-2">
                                                <?= $grade['grade'] ?>
                                            </span>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- Grade Distribution -->
        <div class="card shadow-custom border-radius-custom mb-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-pie-chart"></i> Distribusi Grade
                </h6>
            </div>
            <div class="card-body">
                <?php foreach ($grade_counts as $grade => $count): ?>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-<?= getGradeBadgeColor($grade) ?> me-2"><?= $grade ?></span>
                            <span class="text-muted">Grade <?= $grade ?></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="fw-bold me-2"><?= $count ?></span>
                            <div class="progress" style="width: 60px; height: 8px;">
                                <div class="progress-bar bg-<?= getGradeBadgeColor($grade) ?>" 
                                     style="width: <?= count($grades) > 0 ? ($count / count($grades)) * 100 : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Study Tips -->
        <div class="card shadow-custom border-radius-custom">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-lightbulb"></i> Tips Belajar
                </h6>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <div class="list-group-item border-0 px-0">
                        <div class="d-flex align-items-center">
                            <div class="bg-success rounded-circle p-2 me-3">
                                <i class="bi bi-journal-check text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Rajin Mengerjakan Tugas</h6>
                                <small class="text-muted">Kerjakan tugas tepat waktu</small>
                            </div>
                        </div>
                    </div>
                    <div class="list-group-item border-0 px-0">
                        <div class="d-flex align-items-center">
                            <div class="bg-primary rounded-circle p-2 me-3">
                                <i class="bi bi-clock text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Persiapan UTS & UAS</h6>
                                <small class="text-muted">Belajar rutin sebelum ujian</small>
                            </div>
                        </div>
                    </div>
                    <div class="list-group-item border-0 px-0">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning rounded-circle p-2 me-3">
                                <i class="bi bi-people text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Aktif di Kelas</h6>
                                <small class="text-muted">Bertanya dan berdiskusi</small>
                            </div>
                        </div>
                    </div>
                    <div class="list-group-item border-0 px-0">
                        <div class="d-flex align-items-center">
                            <div class="bg-info rounded-circle p-2 me-3">
                                <i class="bi bi-chat-dots text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Konsultasi Guru</h6>
                                <small class="text-muted">Tanyakan materi yang sulit</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
function getGradeBadgeColor($grade) {
    switch($grade) {
        case 'A': return 'success';
        case 'B': return 'primary';
        case 'C': return 'warning';
        case 'D': return 'info';
        case 'E': return 'danger';
        default: return 'secondary';
    }
}
?>