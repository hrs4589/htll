<?php
// Handle form submission for input/update nilai
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'input') {
        $nis = $_POST['nis'];
        $mapel = $_POST['mapel'];
        $uts = $_POST['uts'];
        $uas = $_POST['uas'];
        $tugas = $_POST['tugas'];
        $na = $_POST['na'];
        $grade = $_POST['grade'];
        
        // Check if record exists
        $stmt = $pdo->prepare("SELECT id FROM nilai WHERE nis = ? AND mapel = ?");
        $stmt->execute([$nis, $mapel]);
        
        if ($stmt->fetch()) {
            // Update existing record
            $stmt = $pdo->prepare("UPDATE nilai SET uts = ?, uas = ?, tugas = ?, na = ?, grade = ? WHERE nis = ? AND mapel = ?");
            $stmt->execute([$uts, $uas, $tugas, $na, $grade, $nis, $mapel]);
            $message = "Nilai berhasil diupdate!";
        } else {
            // Insert new record
            $stmt = $pdo->prepare("INSERT INTO nilai (nis, mapel, uts, uas, tugas, na, grade) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nis, $mapel, $uts, $uas, $tugas, $na, $grade]);
            $message = "Nilai berhasil ditambahkan!";
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM nilai WHERE id = ?");
        $stmt->execute([$id]);
        $message = "Nilai berhasil dihapus!";
    }
}

// Get all students for dropdown
$stmt = $pdo->query("SELECT nis, nama, kelas FROM siswa ORDER BY kelas, nama");
$allStudents = $stmt->fetchAll();

// Get subjects that each student already has grades for
$stmt = $pdo->query("SELECT nis, mapel FROM nilai");
$studentSubjects = [];
while ($row = $stmt->fetch()) {
    if (!isset($studentSubjects[$row['nis']])) {
        $studentSubjects[$row['nis']] = [];
    }
    $studentSubjects[$row['nis']][] = $row['mapel'];
}

// Get all grades for display
$stmt = $pdo->query("
    SELECT n.*, s.nama, s.kelas 
    FROM nilai n 
    INNER JOIN siswa s ON n.nis = s.nis 
    ORDER BY s.kelas, s.nama, n.mapel
");
$grades = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Input Nilai Siswa</h1>
</div>

<?php if (isset($message)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Form Input Nilai</h6>
            </div>
            <div class="card-body">
                <form method="POST" id="nilaiForm">
                    <input type="hidden" name="action" value="input">
                    
                    <div class="mb-3">
                        <label for="nis" class="form-label">Pilih Siswa</label>
                        <select class="form-select" id="nis" name="nis" required onchange="updateSubjectOptions()">
                            <option value="">-- Pilih Siswa --</option>
                            <?php foreach ($allStudents as $student): 
                                $hasAllSubjects = isset($studentSubjects[$student['nis']]) && 
                                                count($studentSubjects[$student['nis']]) >= 3;
                                $disabled = $hasAllSubjects ? 'disabled' : '';
                                $style = $hasAllSubjects ? 'color: #6c757d; background-color: #e9ecef;' : '';
                            ?>
                                <option value="<?= $student['nis'] ?>" <?= $disabled ?> style="<?= $style ?>">
                                    <?= $student['nis'] ?> - <?= $student['nama'] ?> (<?= $student['kelas'] ?>)
                                    <?= $hasAllSubjects ? ' (Sudah lengkap)' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="mapel" class="form-label">Mata Pelajaran</label>
                        <select class="form-select" id="mapel" name="mapel" required>
                            <option value="">-- Pilih Mata Pelajaran --</option>
                            <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                            <option value="Bahasa Inggris">Bahasa Inggris</option>
                            <option value="Matematika">Matematika</option>
                        </select>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="uts" class="form-label">Nilai UTS</label>
                                <input type="number" class="form-control" id="uts" name="uts" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="uas" class="form-label">Nilai UAS</label>
                                <input type="number" class="form-control" id="uas" name="uas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="tugas" class="form-label">Nilai Tugas</label>
                                <input type="number" class="form-control" id="tugas" name="tugas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilai()" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="na" class="form-label">Nilai Akhir (NA)</label>
                                <input type="number" class="form-control" id="na" name="na" 
                                       step="0.01" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="grade" class="form-label">Grade</label>
                                <input type="text" class="form-control" id="grade" name="grade" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Nilai
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="resetForm()">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data Nilai Siswa</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-primary">
                            <tr>
                                <th>Siswa</th>
                                <th>Mapel</th>
                                <th>UTS</th>
                                <th>UAS</th>
                                <th>Tugas</th>
                                <th>NA</th>
                                <th>Grade</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($grades)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">Belum ada data nilai</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($grades as $grade): ?>
                                    <tr>
                                        <td>
                                            <small><?= $grade['nama'] ?><br>
                                            <span class="text-muted"><?= $grade['kelas'] ?></span></small>
                                        </td>
                                        <td><small><?= $grade['mapel'] ?></small></td>
                                        <td><?= $grade['uts'] ?></td>
                                        <td><?= $grade['uas'] ?></td>
                                        <td><?= $grade['tugas'] ?></td>
                                        <td><strong><?= $grade['na'] ?></strong></td>
                                        <td>
                                            <span class="badge bg-<?= getGradeBadgeColor($grade['grade']) ?>">
                                                <?= $grade['grade'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-warning btn-sm edit-btn" 
                                                    data-bs-toggle="modal" data-bs-target="#editModal"
                                                    data-id="<?= $grade['id'] ?>"
                                                    data-nis="<?= $grade['nis'] ?>"
                                                    data-nama="<?= $grade['nama'] ?>"
                                                    data-kelas="<?= $grade['kelas'] ?>"
                                                    data-mapel="<?= $grade['mapel'] ?>"
                                                    data-uts="<?= $grade['uts'] ?>"
                                                    data-uas="<?= $grade['uas'] ?>"
                                                    data-tugas="<?= $grade['tugas'] ?>"
                                                    data-na="<?= $grade['na'] ?>"
                                                    data-grade="<?= $grade['grade'] ?>">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?= $grade['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" 
                                                        onclick="return confirm('Yakin ingin menghapus?')">
                                                  <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Nilai Siswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" id="editForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="input">
                    <input type="hidden" id="edit_id" name="edit_id" value="">
                    
                    <div class="mb-3">
                        <label class="form-label">Siswa</label>
                        <p class="form-control-static" id="edit_nama"></p>
                        <input type="hidden" id="edit_nis" name="nis">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Kelas</label>
                        <p class="form-control-static" id="edit_kelas"></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Mata Pelajaran</label>
                        <p class="form-control-static" id="edit_mapel"></p>
                        <input type="hidden" id="edit_mapel_val" name="mapel">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_uts" class="form-label">Nilai UTS</label>
                                <input type="number" class="form-control" id="edit_uts" name="uts" 
                                       min="0" max="100" step="0.01" oninput="hitungNilaiEdit()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_uas" class="form-label">Nilai UAS</label>
                                <input type="number" class="form-control" id="edit_uas" name="uas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilaiEdit()" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_tugas" class="form-label">Nilai Tugas</label>
                                <input type="number" class="form-control" id="edit_tugas" name="tugas" 
                                       min="0" max="100" step="0.01" oninput="hitungNilaiEdit()" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_na" class="form-label">Nilai Akhir (NA)</label>
                                <input type="number" class="form-control" id="edit_na" name="na" 
                                       step="0.01" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_grade" class="form-label">Grade</label>
                                <input type="text" class="form-control" id="edit_grade" name="grade" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Data mata pelajaran yang sudah diinput oleh siswa
const studentSubjects = <?= json_encode($studentSubjects) ?>;

function hitungNilai() {
    const uts = parseFloat(document.getElementById('uts').value) || 0;
    const uas = parseFloat(document.getElementById('uas').value) || 0;
    const tugas = parseFloat(document.getElementById('tugas').value) || 0;
    
    // Hitung nilai akhir (misal: 30% UTS + 40% UAS + 30% Tugas)
    const na = (uts * 0.3) + (uas * 0.4) + (tugas * 0.3);
    document.getElementById('na').value = na.toFixed(2);
    
    // Tentukan grade
    let grade = '';
    if (na >= 85) grade = 'A';
    else if (na >= 75) grade = 'B';
    else if (na >= 65) grade = 'C';
    else if (na >= 55) grade = 'D';
    else grade = 'E';
    
    document.getElementById('grade').value = grade;
}

function hitungNilaiEdit() {
    const uts = parseFloat(document.getElementById('edit_uts').value) || 0;
    const uas = parseFloat(document.getElementById('edit_uas').value) || 0;
    const tugas = parseFloat(document.getElementById('edit_tugas').value) || 0;
    
    // Hitung nilai akhir (misal: 30% UTS + 40% UAS + 30% Tugas)
    const na = (uts * 0.3) + (uas * 0.4) + (tugas * 0.3);
    document.getElementById('edit_na').value = na.toFixed(2);
    
    // Tentukan grade
    let grade = '';
    if (na >= 85) grade = 'A';
    else if (na >= 75) grade = 'B';
    else if (na >= 65) grade = 'C';
    else if (na >= 55) grade = 'D';
    else grade = 'E';
    
    document.getElementById('edit_grade').value = grade;
}

function resetForm() {
    document.getElementById('nilaiForm').reset();
    document.getElementById('na').value = '';
    document.getElementById('grade').value = '';
    updateSubjectOptions();
}

function updateSubjectOptions() {
    const nis = document.getElementById('nis').value;
    const subjectSelect = document.getElementById('mapel');
    
    // Reset semua opsi
    for (let i = 1; i < subjectSelect.options.length; i++) {
        subjectSelect.options[i].disabled = false;
        subjectSelect.options[i].style.color = '';
        subjectSelect.options[i].style.backgroundColor = '';
    }
    
    // Jika siswa dipilih dan memiliki mata pelajaran yang sudah diinput
    if (nis && studentSubjects[nis]) {
        const takenSubjects = studentSubjects[nis];
        
        // Nonaktifkan mata pelajaran yang sudah diinput
        for (let i = 1; i < subjectSelect.options.length; i++) {
            if (takenSubjects.includes(subjectSelect.options[i].value)) {
                subjectSelect.options[i].disabled = true;
                subjectSelect.options[i].style.color = '#6c757d';
                subjectSelect.options[i].style.backgroundColor = '#e9ecef';
            }
        }
    }
}

// Handle edit button click
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.edit-btn');
    const editModal = new bootstrap.Modal(document.getElementById('editModal'));
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Fill form with data
            document.getElementById('edit_id').value = this.dataset.id;
            document.getElementById('edit_nis').value = this.dataset.nis;
            document.getElementById('edit_nama').textContent = this.dataset.nama;
            document.getElementById('edit_kelas').textContent = this.dataset.kelas;
            document.getElementById('edit_mapel').textContent = this.dataset.mapel;
            document.getElementById('edit_mapel_val').value = this.dataset.mapel;
            document.getElementById('edit_uts').value = this.dataset.uts;
            document.getElementById('edit_uas').value = this.dataset.uas;
            document.getElementById('edit_tugas').value = this.dataset.tugas;
            document.getElementById('edit_na').value = this.dataset.na;
            document.getElementById('edit_grade').value = this.dataset.grade;
        });
    });
    
    // Inisialisasi pilihan mata pelajaran saat pertama kali load
    updateSubjectOptions();
});
</script>

<?php
function getGradeBadgeColor($grade) {
    switch($grade) {
        case 'A': return 'success';
        case 'B': return 'primary';
        case 'C': return 'warning';
        case 'D': return 'info';
        case 'E': return 'danger';
        default: return 'secondary';
    }
}
?>