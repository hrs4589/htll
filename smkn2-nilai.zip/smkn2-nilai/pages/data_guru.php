<?php
// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $nip = $_POST['nip'];
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO guru (nip, nama, email, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nip, $nama, $email, $password]);
        $message = "Guru berhasil ditambahkan!";
        $messageType = "success";
    } elseif ($action === 'update') {
        $id = $_POST['id'];
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        
        $stmt = $pdo->prepare("UPDATE guru SET nama = ?, email = ? WHERE nip = ?");
        $stmt->execute([$nama, $email, $id]);
        $message = "Data guru berhasil diupdate!";
        $messageType = "success";
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM guru WHERE nip = ?");
        $stmt->execute([$id]);
        $message = "Guru berhasil dihapus!";
        $messageType = "success";
    }
}

// Get all teachers
$stmt = $pdo->query("SELECT * FROM guru ORDER BY nama");
$teachers = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
    <h1 class="h2 text-gradient">
        <i class="bi bi-person-workspace"></i> Data Guru
    </h1>
    <div class="btn-toolbar">
        <button class="btn btn-primary me-2" onclick="openAddModal('guru')">
            <i class="bi bi-person-plus"></i> Tambah Guru
        </button>
        <div class="btn-group">
            <button class="btn btn-outline-primary" onclick="exportData('csv', 'guruTable')">
                <i class="bi bi-download"></i> Export
            </button>
            <button class="btn btn-outline-primary" onclick="printTable('guruTable')">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
    </div>
</div>

<?php if (isset($message)): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <i class="bi bi-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-lg-4 col-md-6 mb-3">
        <div class="stats-card success">
            <div class="stats-icon">
                <i class="bi bi-person-workspace"></i>
            </div>
            <div class="stats-number"><?= count($teachers) ?></div>
            <div class="stats-label">Total Guru</div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-3">
        <div class="stats-card primary">
            <div class="stats-icon">
                <i class="bi bi-check-circle"></i>
            </div>
            <div class="stats-number"><?= count($teachers) ?></div>
            <div class="stats-label">Guru Aktif</div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-3">
        <div class="stats-card info">
            <div class="stats-icon">
                <i class="bi bi-book"></i>
            </div>
            <div class="stats-number">3</div>
            <div class="stats-label">Mata Pelajaran</div>
        </div>
    </div>
</div>

<!-- Teachers Table -->
<div class="card shadow-custom border-radius-custom">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-table"></i> Daftar Guru SMKN 2 Magelang
        </h5>
        <div class="input-group" style="width: 300px;">
            <span class="input-group-text">
                <i class="bi bi-search"></i>
            </span>
            <input type="text" class="form-control" placeholder="Cari guru..." 
                   onkeyup="searchTable(this.value, 'guruTable')">
        </div>
    </div>
    <div class="card-body p-0">
        <?php if (empty($teachers)): ?>
            <div class="text-center py-5">
                <i class="bi bi-person-x display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">Belum Ada Data Guru</h4>
                <p class="text-muted">Tambahkan guru pertama untuk memulai.</p>
                <button class="btn btn-primary" onclick="openAddModal('guru')">
                    <i class="bi bi-person-plus"></i> Tambah Guru Pertama
                </button>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table class="table table-hover mb-0" id="guruTable">
                    <thead>
                        <tr>
                            <th><i class="bi bi-hash me-1"></i> NIP</th>
                            <th><i class="bi bi-person me-1"></i> Nama Lengkap</th>
                            <th><i class="bi bi-envelope me-1"></i> Email</th>
                            <th><i class="bi bi-image me-1"></i> Foto</th>
                            <th class="text-center"><i class="bi bi-gear me-1"></i> Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-success fs-6"><?= $teacher['nip'] ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-success rounded-circle p-2 me-3">
                                            <i class="bi bi-person-workspace text-white"></i>
                                        </div>
                                        <strong><?= $teacher['nama'] ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <a href="mailto:<?= $teacher['email'] ?>" class="text-decoration-none">
                                        <i class="bi bi-envelope me-1"></i>
                                        <?= $teacher['email'] ?>
                                    </a>
                                </td>
                                <td>
                                    <img src="assets/img/<?= $teacher['foto'] ?>" 
                                         alt="<?= $teacher['nama'] ?>" 
                                         class="rounded-circle shadow-sm" 
                                         width="40" height="40">
                                </td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="openEditModal('guru', '<?= $teacher['nip'] ?>', <?= htmlspecialchars(json_encode($teacher)) ?>)"
                                                data-bs-toggle="tooltip" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="deleteItem('guru', '<?= $teacher['nip'] ?>', '<?= $teacher['nama'] ?>')"
                                                data-bs-toggle="tooltip" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal for Add/Edit Guru -->
<div class="modal fade" id="guruModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-person-plus"></i> Tambah Guru
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="guruForm" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-hash"></i> NIP
                        </label>
                        <input type="text" class="form-control" name="nip" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-person"></i> Nama Lengkap
                        </label>
                        <input type="text" class="form-control" name="nama" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-envelope"></i> Email
                        </label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    
                    <div class="mb-3" id="passwordField">
                        <label class="form-label">
                            <i class="bi bi-lock"></i> Password
                        </label>
                        <input type="password" class="form-control" name="password" required>
                        <div class="form-text">Password default untuk login guru</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Confirm Delete Modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="bi bi-exclamation-triangle"></i> Konfirmasi Hapus
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <i class="bi bi-person-x display-1 text-danger mb-3"></i>
                <h4>Yakin ingin menghapus guru?</h4>
                <p class="text-muted">Guru <strong id="deleteItemName"></strong> akan dihapus permanen.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Batal
                </button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="deleteItemId">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Override the modal functions for this page
function openAddModal(type) {
    const modal = new bootstrap.Modal(document.getElementById('guruModal'));
    const form = document.getElementById('guruForm');
    
    // Reset form
    form.reset();
    form.action = '';
    
    // Show password field for new teacher
    document.getElementById('passwordField').style.display = 'block';
    document.querySelector('[name="password"]').required = true;
    
    // Update modal title
    document.querySelector('#guruModal .modal-title').innerHTML = '<i class="bi bi-person-plus"></i> Tambah Guru';
    
    // Add hidden input for action
    let actionInput = form.querySelector('[name="action"]');
    if (!actionInput) {
        actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        form.appendChild(actionInput);
    }
    actionInput.value = 'create';
    
    modal.show();
}

function openEditModal(type, id, data) {
    const modal = new bootstrap.Modal(document.getElementById('guruModal'));
    const form = document.getElementById('guruForm');
    
    // Populate form with data
    form.querySelector('[name="nip"]').value = data.nip;
    form.querySelector('[name="nip"]').readOnly = true;
    form.querySelector('[name="nama"]').value = data.nama;
    form.querySelector('[name="email"]').value = data.email;
    
    // Hide password field for edit
    document.getElementById('passwordField').style.display = 'none';
    document.querySelector('[name="password"]').required = false;
    
    // Update modal title
    document.querySelector('#guruModal .modal-title').innerHTML = '<i class="bi bi-pencil-square"></i> Edit Guru';
    
    // Add hidden inputs for action and id
    let actionInput = form.querySelector('[name="action"]');
    if (!actionInput) {
        actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        form.appendChild(actionInput);
    }
    actionInput.value = 'update';
    
    let idInput = form.querySelector('[name="id"]');
    if (!idInput) {
        idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        form.appendChild(idInput);
    }
    idInput.value = id;
    
    modal.show();
}

function deleteItem(type, id, name) {
    document.getElementById('deleteItemName').textContent = name;
    document.getElementById('deleteItemId').value = id;
    
    const modal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
    modal.show();
}
</script>