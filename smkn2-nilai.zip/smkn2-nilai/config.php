<?php
// Database configuration
$host = 'localhost';
$dbname = 'smkn2_nilai';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Start session
session_start();

// Helper function for checking login
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']);
}

// Helper function for checking if user is guru
function isGuru() {
    return isLoggedIn() && $_SESSION['user_type'] === 'guru';
}

// Helper function for checking if user is siswa
function isSiswa() {
    return isLoggedIn() && $_SESSION['user_type'] === 'siswa';
}
?>