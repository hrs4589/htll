// Premium JavaScript for SMKN 2 Magelang Grade System

// Global variables
let currentEditId = null;
let currentEditType = null;

// Main function to calculate grades automatically
function hitungNilai() {
    let uts = parseFloat(document.getElementById("uts").value) || 0;
    let uas = parseFloat(document.getElementById("uas").value) || 0;
    let tugas = parseFloat(document.getElementById("tugas").value) || 0;
    
    // Calculate final grade (NA)
    let na = (uts + uas + tugas) / 3;
    
    // Set NA value with 2 decimal places
    document.getElementById("na").value = na.toFixed(2);
    
    // Determine grade based on NA
    let grade = '';
    if (na >= 90) {
        grade = 'A';
    } else if (na >= 80) {
        grade = 'B';
    } else if (na >= 70) {
        grade = 'C';
    } else if (na >= 50) {
        grade = 'D';
    } else {
        grade = 'E';
    }
    
    // Set grade value
    document.getElementById("grade").value = grade;
    
    // Add visual feedback with colors
    updateGradeDisplay(grade, na);
}

// Function to update grade display with colors
function updateGradeDisplay(grade, na) {
    const gradeInput = document.getElementById("grade");
    const naInput = document.getElementById("na");
    
    if (!gradeInput || !naInput) return;
    
    // Remove existing grade classes
    gradeInput.classList.remove('grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-e');
    naInput.classList.remove('grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-e');
    
    // Add appropriate grade class
    const gradeClass = 'grade-' + grade.toLowerCase();
    gradeInput.classList.add(gradeClass);
    naInput.classList.add(gradeClass);
}

// Function to reset form
function resetForm() {
    const form = document.getElementById("nilaiForm");
    if (form) {
        form.reset();
        
        // Clear calculated fields
        const naField = document.getElementById("na");
        const gradeField = document.getElementById("grade");
        
        if (naField) naField.value = '';
        if (gradeField) gradeField.value = '';
        
        // Remove grade styling
        if (naField && gradeField) {
            naField.classList.remove('grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-e');
            gradeField.classList.remove('grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-e');
        }
    }
}

// Function to validate input values
function validateInput(input) {
    const value = parseFloat(input.value);
    
    if (value < 0) {
        input.value = 0;
        showAlert('Nilai tidak boleh kurang dari 0', 'warning');
    } else if (value > 100) {
        input.value = 100;
        showAlert('Nilai tidak boleh lebih dari 100', 'warning');
    }
    
    // Recalculate after validation
    hitungNilai();
}

// Function to show alerts with modern styling
function showAlert(message, type = 'info', duration = 4000) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert-custom');
    existingAlerts.forEach(alert => alert.remove());
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-custom`;
    alertDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        border-radius: 12px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    alertDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="bi bi-${getAlertIcon(type)} me-2"></i>
            <span>${message}</span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto dismiss
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => alertDiv.remove(), 300);
        }
    }, duration);
}

// Function to get alert icon based on type
function getAlertIcon(type) {
    const icons = {
        'success': 'check-circle-fill',
        'danger': 'exclamation-triangle-fill',
        'warning': 'exclamation-triangle-fill',
        'info': 'info-circle-fill'
    };
    return icons[type] || 'info-circle-fill';
}

// CRUD Functions for Modal Operations

// Open Add Modal
function openAddModal(type) {
    currentEditId = null;
    currentEditType = type;
    
    const modal = new bootstrap.Modal(document.getElementById(`${type}Modal`));
    const form = document.getElementById(`${type}Form`);
    
    // Reset form
    form.reset();
    
    // Update modal title
    const modalTitle = document.querySelector(`#${type}Modal .modal-title`);
    modalTitle.textContent = `Tambah ${getTypeLabel(type)}`;
    
    // Update button text
    const submitBtn = document.querySelector(`#${type}Modal .btn-primary`);
    submitBtn.innerHTML = `<i class="bi bi-plus-circle"></i> Tambah`;
    
    modal.show();
}

// Open Edit Modal
function openEditModal(type, id, data) {
    currentEditId = id;
    currentEditType = type;
    
    const modal = new bootstrap.Modal(document.getElementById(`${type}Modal`));
    const form = document.getElementById(`${type}Form`);
    
    // Populate form with data
    populateForm(form, data);
    
    // Update modal title
    const modalTitle = document.querySelector(`#${type}Modal .modal-title`);
    modalTitle.textContent = `Edit ${getTypeLabel(type)}`;
    
    // Update button text
    const submitBtn = document.querySelector(`#${type}Modal .btn-primary`);
    submitBtn.innerHTML = `<i class="bi bi-pencil-square"></i> Update`;
    
    modal.show();
}

// Populate form with data
function populateForm(form, data) {
    Object.keys(data).forEach(key => {
        const input = form.querySelector(`[name="${key}"]`);
        if (input) {
            input.value = data[key];
        }
    });
}

// Get type label
function getTypeLabel(type) {
    const labels = {
        'siswa': 'Siswa',
        'guru': 'Guru',
        'nilai': 'Nilai'
    };
    return labels[type] || type;
}

// Submit form via AJAX
function submitForm(type) {
    const form = document.getElementById(`${type}Form`);
    const formData = new FormData(form);
    
    // Add action and ID if editing
    if (currentEditId) {
        formData.append('action', 'update');
        formData.append('id', currentEditId);
    } else {
        formData.append('action', 'create');
    }
    
    // Show loading
    const submitBtn = form.querySelector('.btn-primary');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="loading"></span> Menyimpan...';
    submitBtn.disabled = true;
    
    // Simulate AJAX call (replace with actual implementation)
    setTimeout(() => {
        // Hide modal
        const modal = bootstrap.Modal.getInstance(document.getElementById(`${type}Modal`));
        modal.hide();
        
        // Show success message
        showAlert(`${getTypeLabel(type)} berhasil ${currentEditId ? 'diupdate' : 'ditambahkan'}!`, 'success');
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Refresh table (implement actual refresh logic)
        refreshTable(type);
    }, 1000);
}

// Delete item with confirmation
function deleteItem(type, id, name) {
    const modal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
    
    // Update modal content
    document.getElementById('deleteItemName').textContent = name;
    document.getElementById('confirmDeleteBtn').onclick = () => {
        performDelete(type, id, name);
    };
    
    modal.show();
}

// Perform delete operation
function performDelete(type, id, name) {
    // Show loading
    const deleteBtn = document.getElementById('confirmDeleteBtn');
    deleteBtn.innerHTML = '<span class="loading"></span> Menghapus...';
    deleteBtn.disabled = true;
    
    // Simulate AJAX call
    setTimeout(() => {
        // Hide modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('confirmDeleteModal'));
        modal.hide();
        
        // Show success message
        showAlert(`${name} berhasil dihapus!`, 'success');
        
        // Reset button
        deleteBtn.innerHTML = '<i class="bi bi-trash"></i> Hapus';
        deleteBtn.disabled = false;
        
        // Refresh table
        refreshTable(type);
    }, 1000);
}

// Refresh table (implement actual logic)
function refreshTable(type) {
    // This would typically reload the table data
    console.log(`Refreshing ${type} table...`);
    // location.reload(); // Simple refresh, or implement AJAX table update
}

// Search functionality
function searchTable(searchTerm, tableId) {
    const table = document.getElementById(tableId);
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const matches = text.includes(searchTerm.toLowerCase());
        row.style.display = matches ? '' : 'none';
        
        // Highlight matching text
        if (matches && searchTerm) {
            highlightSearchTerm(row, searchTerm);
        } else {
            removeHighlight(row);
        }
    });
}

// Highlight search term
function highlightSearchTerm(row, term) {
    const cells = row.querySelectorAll('td');
    cells.forEach(cell => {
        const text = cell.textContent;
        const regex = new RegExp(`(${term})`, 'gi');
        const highlightedText = text.replace(regex, '<mark>$1</mark>');
        if (text !== highlightedText) {
            cell.innerHTML = highlightedText;
        }
    });
}

// Remove highlight
function removeHighlight(row) {
    const marks = row.querySelectorAll('mark');
    marks.forEach(mark => {
        mark.outerHTML = mark.textContent;
    });
}

// Export functionality
function exportData(format = 'csv', tableId) {
    const table = document.getElementById(tableId);
    const rows = Array.from(table.querySelectorAll('tr'));
    
    if (format === 'csv') {
        exportToCSV(rows);
    } else if (format === 'excel') {
        exportToExcel(rows);
    }
}

// Export to CSV
function exportToCSV(rows) {
    const csvContent = rows.map(row => {
        const cells = Array.from(row.querySelectorAll('th, td'));
        return cells.map(cell => `"${cell.textContent.trim()}"`).join(',');
    }).join('\n');
    
    downloadFile(csvContent, 'data.csv', 'text/csv');
}

// Download file
function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// Print functionality
function printTable(tableId) {
    const table = document.getElementById(tableId);
    const printWindow = window.open('', '_blank');
    
    printWindow.document.write(`
        <html>
            <head>
                <title>Print Data</title>
                <style>
                    body { font-family: Arial, sans-serif; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                </style>
            </head>
            <body>
                <h2>Data SMKN 2 Magelang</h2>
                ${table.outerHTML}
            </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
}

// Animate numbers
function animateNumber(element, finalNumber, duration = 1000) {
    const startNumber = 0;
    const increment = finalNumber / (duration / 16);
    let currentNumber = startNumber;
    
    const timer = setInterval(() => {
        currentNumber += increment;
        if (currentNumber >= finalNumber) {
            currentNumber = finalNumber;
            clearInterval(timer);
        }
        element.textContent = Math.floor(currentNumber);
    }, 16);
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Add input validation for number inputs
    const numberInputs = document.querySelectorAll('input[type="number"]');
    numberInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateInput(this);
        });
        
        // Limit decimal places to 2
        input.addEventListener('input', function() {
            if (this.value.includes('.')) {
                const parts = this.value.split('.');
                if (parts[1] && parts[1].length > 2) {
                    this.value = parseFloat(this.value).toFixed(2);
                }
            }
        });
    });
    
    // Animate numbers on statistics cards
    const statisticNumbers = document.querySelectorAll('.stats-number');
    statisticNumbers.forEach(element => {
        const finalNumber = parseInt(element.textContent);
        if (!isNaN(finalNumber)) {
            animateNumber(element, finalNumber);
        }
    });
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(alert => {
            const bsAlert = new bootstrap.Alert(alert);
            if (bsAlert) bsAlert.close();
        });
    }, 5000);
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add loading states to forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="loading"></span> Memproses...';
                submitBtn.disabled = true;
                
                // Re-enable after 3 seconds (fallback)
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            }
        });
    });
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + S to save form
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        const activeModal = document.querySelector('.modal.show');
        if (activeModal) {
            const form = activeModal.querySelector('form');
            if (form) {
                form.dispatchEvent(new Event('submit'));
            }
        }
    }
    
    // Escape to close modal
    if (e.key === 'Escape') {
        const activeModal = document.querySelector('.modal.show');
        if (activeModal) {
            const modal = bootstrap.Modal.getInstance(activeModal);
            if (modal) modal.hide();
        }
    }
    
    // Ctrl + N for new item
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        const addBtn = document.querySelector('.btn-add');
        if (addBtn) addBtn.click();
    }
});

// Network status check
function checkNetworkStatus() {
    if (!navigator.onLine) {
        showAlert('Koneksi internet terputus. Beberapa fitur mungkin tidak berfungsi.', 'warning');
    }
}

// Check network status on load and when it changes
window.addEventListener('load', checkNetworkStatus);
window.addEventListener('online', () => showAlert('Koneksi internet tersedia kembali.', 'success'));
window.addEventListener('offline', () => showAlert('Koneksi internet terputus.', 'warning'));

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    
    .pulse {
        animation: pulse 2s infinite;
    }
`;
document.head.appendChild(style);