<?php
require_once 'config.php';

// Get current page
$page = $_GET['page'] ?? 'home';

// Check if user is logged in
if (!isLoggedIn() && $page !== 'login') {
    header('Location: index.php?page=login');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Nilai SMKN 2 Magelang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php if (isLoggedIn()): ?>
        <?php include 'includes/navbar.php'; ?>
        <div class="container-fluid">
            <div class="row">
                <?php include 'includes/sidebar.php'; ?>
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div class="content-wrapper">
                        <?php
                        switch($page) {
                            case 'home':
                                include 'pages/home.php';
                                break;
                            case 'data_siswa':
                                include 'pages/data_siswa.php';
                                break;
                            case 'data_guru':
                                include 'pages/data_guru.php';
                                break;
                            case 'nilai_siswa':
                                if (isGuru()) {
                                    include 'pages/nilai_input.php';
                                } else {
                                    include 'pages/nilai_view.php';
                                }
                                break;
                            case 'galeri':
                                include 'pages/galeri.php';
                                break;
                            case 'guru_dashboard':
                                if (isGuru()) {
                                    include 'pages/guru_dashboard.php';
                                } else {
                                    header('Location: index.php');
                                }
                                break;
                            case 'siswa_dashboard':
                                if (isSiswa()) {
                                    include 'pages/siswa_dashboard.php';
                                } else {
                                    header('Location: index.php');
                                }
                                break;
                            default:
                                include 'pages/home.php';
                        }
                        ?>
                    </div>
                </main>
            </div>
        </div>
    <?php else: ?>
        <?php include 'pages/login.php'; ?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>