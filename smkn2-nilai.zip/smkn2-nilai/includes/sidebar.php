<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= ($page === 'home') ? 'active' : '' ?>" href="index.php?page=home">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            
            <?php if (isGuru()): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($page === 'guru_dashboard') ? 'active' : '' ?>" href="index.php?page=guru_dashboard">
                        <i class="bi bi-person-workspace"></i> Dashboard Guru
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if (isSiswa()): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($page === 'siswa_dashboard') ? 'active' : '' ?>" href="index.php?page=siswa_dashboard">
                        <i class="bi bi-person-circle"></i> Dashboard Siswa
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if (isGuru()): ?>
            <li class="nav-item">
                <a class="nav-link <?= ($page === 'data_siswa') ? 'active' : '' ?>" href="index.php?page=data_siswa">
                    <i class="bi bi-people"></i> Data Siswa
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?= ($page === 'data_guru') ? 'active' : '' ?>" href="index.php?page=data_guru">
                    <i class="bi bi-person-workspace"></i> Data Guru
                </a>
            </li>
            <?php endif; ?>
            
            <li class="nav-item">
                <a class="nav-link <?= ($page === 'nilai_siswa') ? 'active' : '' ?>" href="index.php?page=nilai_siswa">
                    <i class="bi bi-clipboard-data"></i> 
                    <?= isGuru() ? 'Input Nilai' : 'Nilai Saya' ?>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?= ($page === 'galeri') ? 'active' : '' ?>" href="index.php?page=galeri">
                    <i class="bi bi-images"></i> Galeri
                </a>
            </li>
        </ul>
    </div>
</nav>