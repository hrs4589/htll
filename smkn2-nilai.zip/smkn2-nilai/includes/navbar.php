<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="assets/img/logo-smk.png" alt="SMKN 2" width="30" height="30" class="d-inline-block align-text-top">
            SMKN 2 Magelang
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=home">
                        <i class="bi bi-house"></i> Home
                    </a>
                </li>
                <?php if (isGuru()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=data_siswa">
                        <i class="bi bi-people"></i> Data Siswa
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=data_guru">
                        <i class="bi bi-person-workspace"></i> Data Guru
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=nilai_siswa">
                        <i class="bi bi-clipboard-data"></i> Nilai Siswa
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=galeri">
                        <i class="bi bi-images"></i> Galeri
                    </a>
                </li>
            </ul>
            
            <div class="navbar-text me-3">
                <i class="bi bi-person-circle"></i> 
                <?= $_SESSION['user_name'] ?> 
                <span class="badge bg-light text-dark"><?= ucfirst($_SESSION['user_type']) ?></span>
            </div>
            
            <a href="logout.php" class="btn btn-outline-light btn-sm">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>